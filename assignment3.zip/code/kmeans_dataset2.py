# K-Means Clustering

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import datetime as dt

# Importing the dataset
dataset = pd.read_csv('letter-recognition.csv')
X = dataset.iloc[:, 1:].values
y = dataset.iloc[:, 0].values

from sklearn.preprocessing import LabelEncoder
labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)

# Splitting the dataset into the Training set and Test set
"""from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)"""

# Feature Scaling
"""from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)
sc_y = StandardScaler()
y_train = sc_y.fit_transform(y_train)"""

# Using the elbow method to find the optimal number of clusters
from sklearn.cluster import KMeans
wcss = []
for i in range(1, 100):
    kmeans = KMeans(n_clusters = i, init = 'k-means++', random_state = 42)
    kmeans.fit(X)
    wcss.append(kmeans.inertia_)
plt.plot(range(1, 100), wcss)
plt.title('The Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()

# Fitting K-Means to the dataset
kmeans = KMeans(n_clusters = 24, init = 'k-means++', random_state = 0)
y_kmeans = kmeans.fit_predict(X)

from sklearn.manifold import TSNE
X_condensed = TSNE(n_components=2, random_state = 0).fit_transform(X)



# prepare for tsne
X_embedded0 = X_condensed[y_kmeans == 0]
X_embedded1 = X_condensed[y_kmeans == 1]
X_embedded2 = X_condensed[y_kmeans == 2]
X_embedded3 = X_condensed[y_kmeans == 3]
X_embedded4 = X_condensed[y_kmeans == 4]
X_embedded5 = X_condensed[y_kmeans == 5]
X_embedded6 = X_condensed[y_kmeans == 6]
X_embedded7 = X_condensed[y_kmeans == 7]
X_embedded8 = X_condensed[y_kmeans == 8]
X_embedded9 = X_condensed[y_kmeans == 9]
X_embedded10 = X_condensed[y_kmeans == 10]
X_embedded11 = X_condensed[y_kmeans == 11]
X_embedded12 = X_condensed[y_kmeans == 12]
X_embedded13 = X_condensed[y_kmeans == 13]
X_embedded14 = X_condensed[y_kmeans == 14]
X_embedded15 = X_condensed[y_kmeans == 15]
X_embedded16 = X_condensed[y_kmeans == 16]
X_embedded17 = X_condensed[y_kmeans == 17]
X_embedded18 = X_condensed[y_kmeans == 18]
X_embedded19 = X_condensed[y_kmeans == 19]
X_embedded20 = X_condensed[y_kmeans == 20]
X_embedded21 = X_condensed[y_kmeans == 21]
X_embedded22 = X_condensed[y_kmeans == 22]
X_embedded23 = X_condensed[y_kmeans == 23]


# Visualising the clusters
plt.scatter(X_embedded0[:, 0], X_embedded0[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded1[:, 0], X_embedded1[:, 1], s = 2, c = '#ff8c66', label = 'Cluster 2')
plt.scatter(X_embedded2[:, 0], X_embedded2[:, 1], s = 2, c = '#ffb366', label = 'Cluster 3')
plt.scatter(X_embedded3[:, 0], X_embedded3[:, 1], s = 2, c = '#ffd966', label = 'Cluster 4')
plt.scatter(X_embedded4[:, 0], X_embedded4[:, 1], s = 2, c = '#ffff66', label = 'Cluster 5')
plt.scatter(X_embedded5[:, 0], X_embedded5[:, 1], s = 2, c = '#d9ff66', label = 'Cluster 6')
plt.scatter(X_embedded6[:, 0], X_embedded6[:, 1], s = 2, c = '#b3ff66', label = 'Cluster 7')
plt.scatter(X_embedded7[:, 0], X_embedded7[:, 1], s = 2, c = '#8cff66', label = 'Cluster 8')
plt.scatter(X_embedded8[:, 0], X_embedded8[:, 1], s = 2, c = '#66ff66', label = 'Cluster 9')
plt.scatter(X_embedded9[:, 0], X_embedded9[:, 1], s = 2, c = '#66ff8c', label = 'Cluster 10')
plt.scatter(X_embedded10[:, 0], X_embedded10[:, 1], s = 2, c = '#66ffb3', label = 'Cluster 11')
plt.scatter(X_embedded11[:, 0], X_embedded11[:, 1], s = 2, c = '#66ffd9', label = 'Cluster 12')
plt.scatter(X_embedded12[:, 0], X_embedded12[:, 1], s = 2, c = '#66ffff', label = 'Cluster 13')
plt.scatter(X_embedded13[:, 0], X_embedded13[:, 1], s = 2, c = '#66d9ff', label = 'Cluster 14')
plt.scatter(X_embedded14[:, 0], X_embedded14[:, 1], s = 2, c = '#66b3ff', label = 'Cluster 15')
plt.scatter(X_embedded15[:, 0], X_embedded15[:, 1], s = 2, c = '#668cff', label = 'Cluster 16')
plt.scatter(X_embedded16[:, 0], X_embedded16[:, 1], s = 2, c = '#6666ff', label = 'Cluster 17')
plt.scatter(X_embedded17[:, 0], X_embedded17[:, 1], s = 2, c = '#8c66ff', label = 'Cluster 18')
plt.scatter(X_embedded18[:, 0], X_embedded18[:, 1], s = 2, c = '#b366ff', label = 'Cluster 19')
plt.scatter(X_embedded19[:, 0], X_embedded19[:, 1], s = 2, c = '#d966ff', label = 'Cluster 20')
plt.scatter(X_embedded20[:, 0], X_embedded20[:, 1], s = 2, c = '#ff66ff', label = 'Cluster 21')
plt.scatter(X_embedded21[:, 0], X_embedded21[:, 1], s = 2, c = '#ff66d9', label = 'Cluster 22')
plt.scatter(X_embedded22[:, 0], X_embedded22[:, 1], s = 2, c = '#ff66b3', label = 'Cluster 23')
plt.scatter(X_embedded23[:, 0], X_embedded23[:, 1], s = 2, c = '#ff668c', label = 'Cluster 24')
plt.scatter(cluster_center_embedded[:, 0], cluster_center_embedded[:, 1], s = 30, c = 'yellow', label = 'Centroids')
plt.title('Clusters of customers')
plt.xlabel('Annual Income (k$)')
plt.ylabel('Spending Score (1-100)')
plt.legend()
plt.show()


# plot cluster with label
X_embedded0 = X_condensed[y == 0]
X_embedded1 = X_condensed[y == 1]
X_embedded2 = X_condensed[y == 2]
X_embedded3 = X_condensed[y == 3]
X_embedded4 = X_condensed[y == 4]
X_embedded5 = X_condensed[y == 5]
X_embedded6 = X_condensed[y == 6]
X_embedded7 = X_condensed[y == 7]
X_embedded8 = X_condensed[y == 8]
X_embedded9 = X_condensed[y == 9]
X_embedded10 = X_condensed[y == 10]
X_embedded11 = X_condensed[y == 11]
X_embedded12 = X_condensed[y == 12]
X_embedded13 = X_condensed[y == 13]
X_embedded14 = X_condensed[y == 14]
X_embedded15 = X_condensed[y == 15]
X_embedded16 = X_condensed[y == 16]
X_embedded17 = X_condensed[y == 17]
X_embedded18 = X_condensed[y == 18]
X_embedded19 = X_condensed[y == 19]
X_embedded20 = X_condensed[y == 20]
X_embedded21 = X_condensed[y == 21]
X_embedded22 = X_condensed[y == 22]
X_embedded23 = X_condensed[y == 23]
X_embedded24 = X_condensed[y == 24]
X_embedded25 = X_condensed[y == 25]


plt.scatter(X_embedded0[:, 0], X_embedded0[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded1[:, 0], X_embedded1[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded2[:, 0], X_embedded2[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded3[:, 0], X_embedded3[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded4[:, 0], X_embedded4[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded5[:, 0], X_embedded5[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded6[:, 0], X_embedded6[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded7[:, 0], X_embedded7[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded8[:, 0], X_embedded8[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded9[:, 0], X_embedded9[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded10[:, 0], X_embedded10[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded11[:, 0], X_embedded11[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded12[:, 0], X_embedded12[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded13[:, 0], X_embedded13[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded14[:, 0], X_embedded14[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded15[:, 0], X_embedded15[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded16[:, 0], X_embedded16[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded17[:, 0], X_embedded17[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded18[:, 0], X_embedded18[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded19[:, 0], X_embedded19[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded20[:, 0], X_embedded20[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded21[:, 0], X_embedded21[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded22[:, 0], X_embedded22[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded23[:, 0], X_embedded23[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
plt.scatter(X_embedded24[:, 0], X_embedded24[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded25[:, 0], X_embedded25[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
