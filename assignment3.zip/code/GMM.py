# K-Means Clustering

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import datetime as dt

# Importing the dataset
dataset = pd.read_csv('test.csv')
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

from sklearn.preprocessing import LabelEncoder
labelencoder_X = LabelEncoder()
X[:, 1] = labelencoder_X.fit_transform(X[:, 1])
X[:, 3] = labelencoder_X.fit_transform(X[:, 3])
X[:, 5] = labelencoder_X.fit_transform(X[:, 5])
X[:, 6] = labelencoder_X.fit_transform(X[:, 6])
X[:, 7] = labelencoder_X.fit_transform(X[:, 7])
X[:, 8] = labelencoder_X.fit_transform(X[:, 8])
X[:, 9] = labelencoder_X.fit_transform(X[:, 9])
X[:, 13] = labelencoder_X.fit_transform(X[:, 13])

labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)


# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X = sc.fit_transform(X)

# Splitting the dataset into the Training set and Test set
"""from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)"""

# Feature Scaling
"""from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)
sc_y = StandardScaler()
y_train = sc_y.fit_transform(y_train)"""

# Using the elbow method to find the optimal number of clusters
from sklearn.mixture import GaussianMixture
BIC = []
for i in range(1, 100):
    GMM = GaussianMixture(n_components = i,random_state = 0)
    GMM.fit(X)
    BIC.append(GMM.bic(X))
plt.plot(range(1, 100), BIC)
plt.title('GMM')
plt.xlabel('Number of components')
plt.ylabel('BIC')
plt.show()

# Fitting K-Means to the dataset
GMM = GaussianMixture(n_components = 26,random_state = 0)
GMM.fit(X)
y_GMM = GMM.predict(X)


from sklearn.manifold import TSNE
X_condensed = TSNE(n_components=2).fit_transform(X)
X_condensed = X_embedded

# Visualising the clusters
# prepare for tsne
X_embedded0 = X_condensed[y_GMM == 0]
X_embedded1 = X_condensed[y_GMM == 1]
X_embedded2 = X_condensed[y_GMM == 2]
X_embedded3 = X_condensed[y_GMM == 3]
X_embedded4 = X_condensed[y_GMM == 4]
X_embedded5 = X_condensed[y_GMM == 5]
X_embedded6 = X_condensed[y_GMM == 6]
X_embedded7 = X_condensed[y_GMM == 7]
X_embedded8 = X_condensed[y_GMM == 8]
X_embedded9 = X_condensed[y_GMM == 9]
X_embedded10 = X_condensed[y_GMM == 10]
X_embedded11 = X_condensed[y_GMM == 11]
X_embedded12 = X_condensed[y_GMM == 12]
X_embedded13 = X_condensed[y_GMM == 13]
X_embedded14 = X_condensed[y_GMM == 14]
X_embedded15 = X_condensed[y_GMM == 15]
X_embedded16 = X_condensed[y_GMM == 16]
X_embedded17 = X_condensed[y_GMM == 17]
X_embedded18 = X_condensed[y_GMM == 18]
X_embedded19 = X_condensed[y_GMM == 19]
X_embedded20 = X_condensed[y_GMM == 20]
X_embedded21 = X_condensed[y_GMM == 21]
X_embedded22 = X_condensed[y_GMM == 22]
X_embedded23 = X_condensed[y_GMM == 23]
X_embedded24 = X_condensed[y_GMM == 24]
X_embedded25 = X_condensed[y_GMM == 25]

# Visualising the clusters
plt.scatter(X_embedded0[:, 0], X_embedded0[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X_embedded1[:, 0], X_embedded1[:, 1], s = 2, c = '#ff8c66', label = 'Cluster 2')
plt.scatter(X_embedded2[:, 0], X_embedded2[:, 1], s = 2, c = '#ffb366', label = 'Cluster 3')
plt.scatter(X_embedded3[:, 0], X_embedded3[:, 1], s = 2, c = '#ffd966', label = 'Cluster 4')
plt.scatter(X_embedded4[:, 0], X_embedded4[:, 1], s = 2, c = '#ffff66', label = 'Cluster 5')
plt.scatter(X_embedded5[:, 0], X_embedded5[:, 1], s = 2, c = '#d9ff66', label = 'Cluster 6')
plt.scatter(X_embedded6[:, 0], X_embedded6[:, 1], s = 2, c = '#b3ff66', label = 'Cluster 7')
plt.scatter(X_embedded7[:, 0], X_embedded7[:, 1], s = 2, c = '#8cff66', label = 'Cluster 8')
plt.scatter(X_embedded8[:, 0], X_embedded8[:, 1], s = 2, c = '#66ff66', label = 'Cluster 9')
plt.scatter(X_embedded9[:, 0], X_embedded9[:, 1], s = 2, c = '#66ff8c', label = 'Cluster 10')
plt.scatter(X_embedded10[:, 0], X_embedded10[:, 1], s = 2, c = '#66ffb3', label = 'Cluster 11')
plt.scatter(X_embedded11[:, 0], X_embedded11[:, 1], s = 2, c = '#66ffd9', label = 'Cluster 12')
plt.scatter(X_embedded12[:, 0], X_embedded12[:, 1], s = 2, c = '#66ffff', label = 'Cluster 13')
plt.scatter(X_embedded13[:, 0], X_embedded13[:, 1], s = 2, c = '#66d9ff', label = 'Cluster 14')
plt.scatter(X_embedded14[:, 0], X_embedded14[:, 1], s = 2, c = '#66b3ff', label = 'Cluster 15')
plt.scatter(X_embedded15[:, 0], X_embedded15[:, 1], s = 2, c = '#668cff', label = 'Cluster 16')
plt.scatter(X_embedded16[:, 0], X_embedded16[:, 1], s = 2, c = '#6666ff', label = 'Cluster 17')
plt.scatter(X_embedded17[:, 0], X_embedded17[:, 1], s = 2, c = '#8c66ff', label = 'Cluster 18')
plt.scatter(X_embedded18[:, 0], X_embedded18[:, 1], s = 2, c = '#b366ff', label = 'Cluster 19')
plt.scatter(X_embedded19[:, 0], X_embedded19[:, 1], s = 2, c = '#d966ff', label = 'Cluster 20')
plt.scatter(X_embedded20[:, 0], X_embedded20[:, 1], s = 2, c = '#ff66ff', label = 'Cluster 21')
plt.scatter(X_embedded21[:, 0], X_embedded21[:, 1], s = 2, c = '#ff66d9', label = 'Cluster 22')
plt.scatter(X_embedded22[:, 0], X_embedded22[:, 1], s = 2, c = '#ff66b3', label = 'Cluster 23')
plt.scatter(X_embedded23[:, 0], X_embedded23[:, 1], s = 2, c = '#ff668c', label = 'Cluster 24')
plt.scatter(X_embedded24[:, 0], X_embedded24[:, 1], s = 2, c = '#ad84a6', label = 'Cluster 25')
plt.scatter(X_embedded25[:, 0], X_embedded25[:, 1], s = 2, c = '#adc559', label = 'Cluster 26')
