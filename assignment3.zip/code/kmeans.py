# K-Means Clustering

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import datetime as dt

# Importing the dataset
dataset = pd.read_csv('test.csv')
X = dataset.iloc[:, :-1].values
y = dataset.iloc[:, -1].values

from sklearn.preprocessing import LabelEncoder
labelencoder_X = LabelEncoder()
X[:, 1] = labelencoder_X.fit_transform(X[:, 1])
X[:, 3] = labelencoder_X.fit_transform(X[:, 3])
X[:, 5] = labelencoder_X.fit_transform(X[:, 5])
X[:, 6] = labelencoder_X.fit_transform(X[:, 6])
X[:, 7] = labelencoder_X.fit_transform(X[:, 7])
X[:, 8] = labelencoder_X.fit_transform(X[:, 8])
X[:, 9] = labelencoder_X.fit_transform(X[:, 9])
X[:, 13] = labelencoder_X.fit_transform(X[:, 13])

labelencoder_y = LabelEncoder()
y = labelencoder_y.fit_transform(y)


# Feature Scaling
from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X = sc.fit_transform(X)

# Splitting the dataset into the Training set and Test set
"""from sklearn.cross_validation import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)"""

# Feature Scaling
"""from sklearn.preprocessing import StandardScaler
sc_X = StandardScaler()
X_train = sc_X.fit_transform(X_train)
X_test = sc_X.transform(X_test)
sc_y = StandardScaler()
y_train = sc_y.fit_transform(y_train)"""

# Using the elbow method to find the optimal number of clusters
from sklearn.cluster import KMeans
wcss = []
for i in range(1, 100):
    kmeans = KMeans(n_clusters = i, init = 'k-means++', random_state = 0)
    kmeans.fit(X)
    wcss.append(kmeans.inertia_)
plt.plot(range(1, 100), wcss)
plt.title('The Elbow Method')
plt.xlabel('Number of clusters')
plt.ylabel('WCSS')
plt.show()


# Fitting K-Means to the dataset
from sklearn.cluster import KMeans
kmeans = KMeans(n_clusters = 21, init = 'k-means++', random_state = 0)
y_kmeans = kmeans.fit_predict(X)


from sklearn.manifold import TSNE
X_embedded = TSNE(n_components=2, random_state = 0).fit_transform(X)

# prepare for tsne
X0 = X_embedded[y_kmeans == 0]
X1 = X_embedded[y_kmeans == 1]
X2 = X_embedded[y_kmeans == 2]
X3 = X_embedded[y_kmeans == 3]
X4 = X_embedded[y_kmeans == 4]
X5 = X_embedded[y_kmeans == 5]
X6 = X_embedded[y_kmeans == 6]
X7 = X_embedded[y_kmeans == 7]
X8 = X_embedded[y_kmeans == 8]
X9 = X_embedded[y_kmeans == 9]
X10 = X_embedded[y_kmeans == 10]
X11 = X_embedded[y_kmeans == 11]
X12 = X_embedded[y_kmeans == 12]
X13 = X_embedded[y_kmeans == 13]
X14 = X_embedded[y_kmeans == 14]
X15 = X_embedded[y_kmeans == 15]
X16 = X_embedded[y_kmeans == 16]
X17 = X_embedded[y_kmeans == 17]
X18 = X_embedded[y_kmeans == 18]
X19 = X_embedded[y_kmeans == 19]
X20 = X_embedded[y_kmeans == 20]



# Visualising the clusters
plt.scatter(X0[:, 0], X0[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X1[:, 0], X1[:, 1], s = 2, c = '#ff8c66', label = 'Cluster 2')
plt.scatter(X2[:, 0], X2[:, 1], s = 2, c = '#ffb366', label = 'Cluster 3')
plt.scatter(X3[:, 0], X3[:, 1], s = 2, c = '#ffd966', label = 'Cluster 4')
plt.scatter(X4[:, 0], X4[:, 1], s = 2, c = '#ffff66', label = 'Cluster 5')
plt.scatter(X5[:, 0], X5[:, 1], s = 2, c = '#d9ff66', label = 'Cluster 6')
plt.scatter(X6[:, 0], X6[:, 1], s = 2, c = '#b3ff66', label = 'Cluster 7')
plt.scatter(X7[:, 0], X7[:, 1], s = 2, c = '#8cff66', label = 'Cluster 8')
plt.scatter(X8[:, 0], X8[:, 1], s = 2, c = '#66ff66', label = 'Cluster 9')
plt.scatter(X9[:, 0], X9[:, 1], s = 2, c = '#66ff8c', label = 'Cluster 10')
plt.scatter(X10[:, 0], X10[:, 1], s = 2, c = '#66ffb3', label = 'Cluster 11')
plt.scatter(X11[:, 0], X11[:, 1], s = 2, c = '#66ffd9', label = 'Cluster 12')
plt.scatter(X12[:, 0], X12[:, 1], s = 2, c = '#66ffff', label = 'Cluster 13')
plt.scatter(X13[:, 0], X13[:, 1], s = 2, c = '#66d9ff', label = 'Cluster 14')
plt.scatter(X14[:, 0], X14[:, 1], s = 2, c = '#66b3ff', label = 'Cluster 15')
plt.scatter(X15[:, 0], X15[:, 1], s = 2, c = '#668cff', label = 'Cluster 16')
plt.scatter(X16[:, 0], X16[:, 1], s = 2, c = '#6666ff', label = 'Cluster 17')
plt.scatter(X17[:, 0], X17[:, 1], s = 2, c = '#8c66ff', label = 'Cluster 18')
plt.scatter(X18[:, 0], X18[:, 1], s = 2, c = '#b366ff', label = 'Cluster 19')
plt.scatter(X19[:, 0], X19[:, 1], s = 2, c = '#d966ff', label = 'Cluster 20')
plt.scatter(X20[:, 0], X20[:, 1], s = 2, c = '#ff66ff', label = 'Cluster 21')
plt.scatter(cluster_center_embedded[:, 0], cluster_center_embedded[:, 1], s = 30, c = 'yellow', label = 'Centroids')
plt.title('Clusters of customers')
plt.xlabel('Annual Income (k$)')
plt.ylabel('Spending Score (1-100)')
plt.legend()
plt.show()




# cluster with label
X0 = X_embedded[y == 0]
X1 = X_embedded[y == 1]


plt.scatter(X0[:, 0], X0[:, 1], s = 2, c = '#ff6666', label = 'Cluster 1')
plt.scatter(X1[:, 0], X1[:, 1], s = 2, c = '#8cff66', label = 'Cluster 2')
