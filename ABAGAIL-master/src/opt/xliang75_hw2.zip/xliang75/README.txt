The data file is phishing.csv.
Download ABAGAIL package from: https://github.com/pushkar/ABAGAIL
copy source code to src/opt/xliang75/
compile abajail.jar and code and run the tests.